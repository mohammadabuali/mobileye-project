from load_model import model
from utils import crop_img, export_learn_data


import numpy as np
from PIL import Image
from part1.find_abuali import find_tfl_lights


from part1.find_tfl import show_plot#, find_tfl_lights


import glob,os

def test1(filename):
    my_pic = np.array(Image.open(filename))
    positions, aux = find_tfl_lights(my_pic)
    show_plot(my_pic,positions, aux)
    x, y= detect_and_filter(my_pic, positions, aux)
    print(positions)
    print('origin :', len(positions))
    print('filtered :', len(x))
    show_plot(my_pic,x, y)


path = './temp'


def detect_and_filter(image, positions, aux):
    filtered_positions = []
    filtered_aux = []
    bin_data = []
    for position in positions:
        center = (position[0], position[1])
        cropped = crop_img(image, center)
        bin_data.append(cropped)
    l_predictions = model.predict(np.array(bin_data))
    for i in range(len(positions)):
        if l_predictions[i][1] > 0.80:
            filtered_positions.append(positions[i])
            filtered_aux.append(aux[i])
    return filtered_positions, filtered_aux


if __name__ == '__main__':

    # dirname = '../frankfurt/'
    # origin_pics_list = glob.glob(os.path.join( dirname, '*_leftImg8bit.png'))
    # for i, filename in enumerate(origin_pics_list):
    #     test1(filename)
    # path = '../part3/dusseldorf_000049_000024_leftImg8bit.png'
    # test1(path)
    for i in range(24, 30):
        numStr = str(i)
        numStr = numStr.zfill(6)
        path = f'../part3/dusseldorf_000049_{numStr}_leftImg8bit.png'
        test1(path)