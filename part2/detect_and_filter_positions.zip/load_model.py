
import tensorflow as tf

model = tf.keras.models.load_model('../detector/model.h5', compile=False)

